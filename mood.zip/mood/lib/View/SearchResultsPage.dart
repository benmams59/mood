import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mood/Components/AdvancedListItem.dart';
import 'package:mood/Components/ArtistsList.dart';
import 'package:mood/Style/Style.dart';
import 'package:mood/Components/CondensedCard.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SearchResultsPage extends StatefulWidget {
  String query;
  SearchResultsPage(this.query, {Key key}) : super(key: key);

  @override
  _SearchResultsPageState createState() => _SearchResultsPageState();
}

class _SearchResultsPageState extends State<SearchResultsPage> {

  List _songs = new List();
  List _artists = new List();
  List _albums = new List();

  _search() async {
    final songsData = await http.get(
      "https://api.deezer.com/search/track/?q=${widget.query}&limit=50&output=json"
    );
    final artistsData = await http.get(
        "https://api.deezer.com/search/artist/?q=${widget.query}&limit=50&output=json"
    );
    final albumsData = await http.get(
        "https://api.deezer.com/search/album/?q=${widget.query}&limit=50&output=json"
    );

    if (songsData.statusCode == 200)
      _songs = jsonDecode(songsData.body)["data"];

    if (artistsData.statusCode == 200)
      _artists = jsonDecode(artistsData.body)["data"];

    if (albumsData.statusCode == 200)
      _albums = jsonDecode(albumsData.body)["data"];

    setState(() { });
  }

  Widget _showComponents () {
    return _songs.isNotEmpty || _artists.isNotEmpty || _albums.isNotEmpty ?
        SingleChildScrollView(scrollDirection: Axis.vertical, child: Center(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 0, horizontal: 10),
              child: Column(
                children: [
                  SizedBox(height: 20,),
                  Text("Results of ${widget.query}", style: Style.h1,),
                  SizedBox(height: 20,),
                  Column(
                    children: [
                      if (_artists.isNotEmpty)
                        CondensedCard(
                          title: "Artists",
                          child: ArtistsList(artists: _artists,),
                        ),
                      SizedBox(height: 10,),
                      if (_songs.isNotEmpty)
                        CondensedCard(
                          title: "Songs",
                          child: Column(
                            children: _songs.sublist(0, _songs.length > 4 ? 4 : _songs.length)
                            .map((song) => AdvancedListItem(
                              title: song["title"],
                              iconButton: IconButton(
                                icon: Icon(Icons.play_circle_outline),
                                onPressed: () => {},
                              ),
                            )).toList()
                          ),
                        ),
                      SizedBox(height: 10,),
                      if (_albums.isNotEmpty)
                        CondensedCard(
                          title: "Albums",
                          child: Column(
                              children: _albums.sublist(0, _albums.length > 4 ? 4 : _albums.length)
                                  .map((album) => AdvancedListItem(
                                title: album["title"],
                                image: album["cover_small"],
                              )).toList()
                          ),
                        )
                    ],
                  )
                ],
              ),
            )
        ))
        :
        Center(
          child: CircularProgressIndicator(),
        );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _search();
  }

  @override
  Widget build(BuildContext context) {
    return _showComponents();
  }
}