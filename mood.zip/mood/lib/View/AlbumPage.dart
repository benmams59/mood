import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mood/Model/MoodModel.dart';
import 'dart:convert';
import 'package:flutter_sound/flutter_sound.dart';

import 'package:scoped_model/scoped_model.dart';

class AlbumPage extends StatefulWidget {
  int id;

  AlbumPage(this.id, {Key key}) : super(key: key);

  @override
  _AlbumPageState createState() => _AlbumPageState();
}

class _AlbumPageState extends State<AlbumPage> {

  List _tracklist = List();

  _buildAlbums() async {
    final request = await http.get("https://api.deezer.com/album/${widget.id}/tracks");

    if (request.statusCode == 200) {
      setState(() {
        _tracklist = jsonDecode(request.body)["data"];
      });
    }
  }

  Widget _getTracklist() {
    if (_tracklist.isNotEmpty) {
      return Column(
        children: _tracklist.map((element) => ScopedModelDescendant<MoodModel>(
          builder: (context, child, model) {
            return ListTile(
              title: Text(element["title"]),
              trailing: IconButton(
                icon: model.playerID == element["id"] ?
                Icon(Icons.pause) :
                Icon(Icons.play_arrow),
                onPressed: () => {
                  model.player.startPlayer(
                    fromURI: element["preview"],
                    codec: Codec.mp3,
                    whenFinished: () {
                      setState(() {
                        model.setPlayerID(-1);
                      });
                    }
                  )
                },
              ),
            );
          }
        )).toList(),
      );
    } else {
      return Center(
        child: CircularProgressIndicator(),
      );
    }
  }

  @override
  void initState() {
    _buildAlbums();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: _getTracklist()
      ),
    );
  }
}