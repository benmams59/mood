import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:mood/Style/Style.dart';
import 'package:mood/View/AlbumPage.dart';

class ArtistPage extends StatefulWidget {
  dynamic artist;
  ArtistPage({Key key, this.artist}) : super(key: key);

  @override
  _ArtistPageState createState() => _ArtistPageState();
}

class _ArtistPageState extends State<ArtistPage> {

  Map<dynamic, dynamic> _data = Map();
  
  _build() async {
    dynamic request = await http.get(widget.artist["tracklist"]);

    if (request.statusCode == 200) {
      request = jsonDecode(request.body)["data"];
      for (int i = 0; i < request.length; i++) {
        if (!_data.keys.contains(request[i]["album"]["title"])) {
          _data[request[i]["album"]["title"]] =
          [request[i]["album"]["id"], request[i]["album"]["cover_medium"]];
        }
      }
    }
    //print(_data);

    setState(() {});
  }

  @override
  void initState() {
    super.initState();

    _build();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Opacity(
          opacity: 0,
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: Image.network(
                  widget.artist["picture_medium"],
                  width: 50,
                  height: 50,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(width: 10,),
              Text(
                widget.artist["name"],
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 18
                ),
              )
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.more_vert),
            onPressed: () => {},
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20,),
            Center(
              child: Column(
                children: [
                  Hero(
                    tag: "artist${widget.artist["id"]}",
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(100),
                      child: Image.network(
                        widget.artist["picture_medium"],
                        height: 200,
                        width: 200,
                        fit: BoxFit.cover,
                      ),
                    )
                  ),
                  SizedBox(height: 40,),
                  Text(
                    "${widget.artist["name"]}",
                    style: TextStyle(
                        fontSize: 26
                    ),
                  ),
                  SizedBox(height: 10,),
                  FlatButton.icon(
                    onPressed: () => {},
                    label: Text(
                      "Play something",
                      style: TextStyle(
                          fontSize: 18
                      ),
                    ),
                    icon: Icon(Icons.shuffle),
                    color: Color.fromRGBO(0, 0, 0, 0.05),
                    padding: EdgeInsets.all(12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)
                    ),
                  ),
                  SizedBox(height: 10),
                  /*Text(
                    "Some betters songs:",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16
                    ),
                  ),*/
                ],
              )
            ),
            SizedBox(height: 10,),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  onTap: () => {},
                  title: Text(
                    "Discographie",
                    style: TextStyle(
                        fontSize: 24
                    ),
                  ),
                  trailing: Icon(Icons.arrow_forward_ios),
                ),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                  child: _data.isNotEmpty ? Wrap(
                    children: _data.keys.toList().sublist(0, 5).map((element) =>  InkWell(
                      onTap: () => {
                        Navigator.push(context, MaterialPageRoute(
                            builder: (BuildContext context) {
                              return AlbumPage(_data[element][0]);
                            }
                        ))
                      },
                      child: Container(
                        clipBehavior: Clip.antiAlias,
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8)
                        ),
                        width: 120,
                        height: 120,
                        child: Stack(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                _data[element][1],
                                width: 120,
                                height: 120,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Container(
                              width: 120,
                              height: 120,
                              alignment: Alignment.bottomCenter,
                              decoration: BoxDecoration(
                                  color: Color.fromRGBO(0, 0, 0, 0.2),
                                borderRadius: BorderRadius.circular(8)
                              ),
                              child: Text(
                                element,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    )).toList(),
                  ) : Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}