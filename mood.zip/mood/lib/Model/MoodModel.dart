import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:flutter_sound/flutter_sound.dart';

class MoodModel extends Model {
  int _playerID = -1;
  bool _playerInitialized = false;
  FlutterSoundPlayer _player;

  MoodModel() {
    _player = FlutterSoundPlayer();
  }

  int get playerID => _playerID;
  bool get initialized => _playerInitialized;
  FlutterSoundPlayer get player => _player;

  void setPlayerID(int id) {
    _playerID = id;
  }

  void initialize() {
    _player.openAudioSession();
  }
}