package com.nmms.mood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
